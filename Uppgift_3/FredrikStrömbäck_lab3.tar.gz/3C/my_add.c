#include <stdio.h>
#include "my_add.h"

int add(int x, int y)
{
  int sum = x + y;

  return sum;
}

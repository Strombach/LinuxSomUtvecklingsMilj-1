#ifndef __MY_ADD_H__
#define __MY_ADD_H__

int add(int x, int y);

#endif
